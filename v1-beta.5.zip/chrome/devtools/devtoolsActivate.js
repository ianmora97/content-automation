chrome.devtools.panels.create(
    "Content Automation",
    null,
    '../devtools/devtools.html'
);