## Content Automation Chrome Extension
---
1. Unpack .zip
2. Go to chrome://extensions/
3. Enable Developer Mode
4. Click on Load unpacked
5. Upload "chrome" folder

