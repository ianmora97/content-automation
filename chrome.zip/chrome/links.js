chrome.runtime.onInstalled.addListener(() => {
    console.log('Links loaded');
});
