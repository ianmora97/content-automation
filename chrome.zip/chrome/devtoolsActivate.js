chrome.devtools.panels.create(
    "Content Automation",
    null,
    'devtools.html'
);